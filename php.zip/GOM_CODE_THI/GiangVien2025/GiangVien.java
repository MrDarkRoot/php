package com.example.myapplication;

public class GiangVien {
    private  int ma;
    private String ho_ten;
    private String email;
    private String chuyen_mon;
    private Boolean dang_day;

    public int getMa() {
        return ma;
    }

    public void setMa(int ma) {
        this.ma = ma;
    }

    public Boolean getDang_day() {
        return dang_day;
    }

    public void setDang_day(Boolean dang_day) {
        this.dang_day = dang_day;
    }

    public String getChuyen_mon() {
        return chuyen_mon;
    }

    public void setChuyen_mon(String chuyen_mon) {
        this.chuyen_mon = chuyen_mon;
    }

    public String getHo_ten() {
        return ho_ten;
    }

    public void setHo_ten(String ho_ten) {
        this.ho_ten = ho_ten;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public GiangVien(int ma, String ho_ten, String email, String chuyen_mon, Boolean dang_day) {
        this.ma = ma;
        this.ho_ten = ho_ten;
        this.email = email;
        this.chuyen_mon = chuyen_mon;
        this.dang_day = dang_day;
    }

    public GiangVien() {
    }

    @Override
    public String toString() {
        String trangThai = dang_day ? "CON" : "NGHI";
        return  "Ma:" + ma + "\n" +
                "Ho Ten:" + ho_ten + "\n" +
                "Email:" + email + "\n" +
                "Chuyen mon:"+ chuyen_mon +"\n"
                + "Trang Thai Day Hoc:" + trangThai ;
    }
}
