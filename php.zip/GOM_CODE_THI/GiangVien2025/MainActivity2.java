package com.example.myapplication;

import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    String URL = "http://192.168.1.8/onthi/de2_giangvien/api.php";

    ArrayList<GiangVien> list = new ArrayList<>();
    ArrayAdapter<GiangVien> adapter;
    EditText edtTen, edtEmail, edtChuyenMon, edtDangDay, edtMa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_main);

        edtMa = findViewById(R.id.edtMa);
        edtTen = findViewById(R.id.edtTen);
        edtEmail = findViewById(R.id.edtEmail);
        edtChuyenMon = findViewById(R.id.edtChuyenMon);
        edtDangDay = findViewById(R.id.edtDangDay);
        ListView listView = findViewById(R.id.ListViewMain);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);

        findViewById(R.id.btnThem).setOnClickListener(view -> addData());

        // SỰ KIỆN CLICK: Chọn item để đưa dữ liệu lên EditText
        listView.setOnItemClickListener((parent, view, position, id) -> {
            GiangVien gv = list.get(position);
            edtMa.setText(String.valueOf(gv.getMa()));
            edtTen.setText(gv.getHo_ten());
            edtEmail.setText(gv.getEmail());
            edtChuyenMon.setText(gv.getChuyen_mon());
            edtDangDay.setText(String.valueOf(gv.getDang_day()));
        });

        // SỰ KIỆN XÓA: Nhấn giữ item để xóa
        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            deleteData(list.get(position).getMa());
            return true;
        });

        loadData();
    }

    void callApi(String url, Runnable onSuccess) {
        Volley.newRequestQueue(this).add(new StringRequest(Request.Method.GET, url,
                res -> {
                    try {
                        JSONObject json = new JSONObject(res);
                        JSONArray arr = json.optJSONArray("DS_GIANG_VIEN");
                        if (arr != null) {
                            list.clear();
                            for (int i = 0; i < arr.length(); i++) {
                                JSONObject o = arr.getJSONObject(i);
                                // TRICK 2: Ép kiểu Boolean nhanh từ chuỗi "TRUE"/"FALSE"
                                list.add(new GiangVien(
                                        o.optInt("MA_GIANG_VIEN"),
                                        o.optString("HO_TEN"),
                                        o.optString("EMAIL"),
                                        o.optString("CHUYEN_MON"),
                                        o.optString("DANG_DAY").equalsIgnoreCase("TRUE")
                                ));
                            }
                            adapter.notifyDataSetChanged();
                        }

                        // TRICK 3: Dùng key "ok" hoặc "success" chung cho mọi thao tác Insert/Delete/Update
                        // Theo JSON bạn gửi: "ok": true
                        if (json.optBoolean("ok") || json.optInt("success") == 1) {
                            if (onSuccess != null) {
                                onSuccess.run(); // Tự động loadData() lại
                                Toast.makeText(this, "Thành công!", Toast.LENGTH_SHORT).show();
                            }
                        }

                    } catch (Exception e) { e.printStackTrace(); }
                },
                err -> Toast.makeText(this, "Lỗi mạng", Toast.LENGTH_SHORT).show()
        ));
    }

    private void loadData() {
        callApi(URL + "?action=getall", null);
    }

    private void addData() {
        // MAPPING GỬI ĐI: Phải khớp $_REQUEST['ho_ten'] và $_REQUEST['email']
        String url = Uri.parse(URL).buildUpon()
                .appendQueryParameter("action", "insert")
                .appendQueryParameter("ho_ten", edtTen.getText().toString()) // Đổi từ hoTen thành ho_ten
                .appendQueryParameter("email", edtEmail.getText().toString())
                .appendQueryParameter("chuyen_mon", edtChuyenMon.getText().toString())
                .appendQueryParameter("dang_day", edtDangDay.getText().toString())
                .toString();
        callApi(url, this::loadData);
    }

    private void deleteData(int maGiangVien) {
        // MAPPING GỬI ĐI: Khóa chính là ma_giang_vien
        String url = Uri.parse(URL).buildUpon()
                .appendQueryParameter("action", "delete")
                .appendQueryParameter("ma_giang_vien", String.valueOf(maGiangVien))
                .toString();
        callApi(url, this::loadData);
    }
}
