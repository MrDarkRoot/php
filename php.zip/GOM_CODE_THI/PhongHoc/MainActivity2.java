package com.example.phonghoc;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Iterator;

public class MainActivity2 extends AppCompatActivity {
    String URL = "http://192.168.1.8/v/de4_phonghoc/api.php";
    ArrayList<PhongHoc> list = new ArrayList<>();
    ArrayAdapter<PhongHoc> adapter;
    EditText edtTen, edtSucChua, edtMayChieu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);

        edtTen = findViewById(R.id.edtTen);
        edtSucChua = findViewById(R.id.edtSucChua);
        edtMayChieu = findViewById(R.id.edtMayChieu);
        ListView lv = findViewById(R.id.listViewMain);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        lv.setAdapter(adapter);

        findViewById(R.id.btnThem).setOnClickListener(v -> addData());

        // TRICK: Xóa nhanh bằng LongClick
        lv.setOnItemLongClickListener((p, v, pos, id) -> {
            new AlertDialog.Builder(this).setTitle("Xóa?")
                    .setPositiveButton("Có", (d, w) -> deleteData(list.get(pos).getMa()))
                    .setNegativeButton("Không", null).show();
            return true;
        });

        loadData();
    }

    private void callApi(String url, Runnable onSuccess) {
        Volley.newRequestQueue(this).add(new StringRequest(Request.Method.GET, url,
                res -> {
                    try {
                        JSONObject json = new JSONObject(res);
                        // TRICK: Bóc vỏ hành tầng data -> items_by_id
                        JSONObject items = json.optJSONObject("data").optJSONObject("items_by_id");

                        if (items != null) {
                            list.clear();
                            Iterator<String> keys = items.keys();
                            while (keys.hasNext()) {
                                String id = keys.next();
                                JSONObject o = items.getJSONObject(id);
                                list.add(new PhongHoc(Integer.parseInt(id),
                                        o.optString("TEN_PHONG"), o.optInt("SUC_CHUA"), o.optBoolean("CO_MAY_CHIEU")));
                            }
                            adapter.notifyDataSetChanged();
                        }
                        if (onSuccess != null) onSuccess.run();
                    } catch (Exception e) { e.printStackTrace(); }
                },
                err -> Toast.makeText(this, "Lỗi mạng!", Toast.LENGTH_SHORT).show()));
    }

    private void loadData() {
        callApi(URL + "?action=getall", null);
    }

    private void addData() {
//        String t = edtTen.getText().toString(), s = edtSucChua.getText().toString(), m = edtMayChieu.getText().toString();
//        if(t.isEmpty() || s.isEmpty()) return; // Trick: validate nhanh để đi tiếp
//
//        String url = URL + "?action=insert&ten_phong=" + t + "&suc_chua=" + s + "&co_may_chieu=" + m;
//        callApi(url, () -> {
//            loadData(); // Xong thì load lại
//            edtTen.setText(""); edtSucChua.setText(""); edtMayChieu.setText("");
//        });
    }

    private void deleteData(int id) {
//        callApi(URL + "?action=delete&ma_phong=" + id, this::loadData);
    }
}