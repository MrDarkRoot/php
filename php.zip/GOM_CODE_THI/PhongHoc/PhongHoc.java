package com.example.phonghoc;

public class PhongHoc {
    private int ma;
    private String ten_phong;
    private int suc_chua;
    private boolean co_may_chieu;

    public PhongHoc(int ma, String ten_phong, int suc_chua, boolean co_may_chieu) {
        this.ma = ma;
        this.ten_phong = ten_phong;
        this.suc_chua = suc_chua;
        this.co_may_chieu = co_may_chieu;
    }

    public PhongHoc(String ten_phong, int suc_chua, boolean co_may_chieu) {
        this.ten_phong = ten_phong;
        this.suc_chua = suc_chua;
        this.co_may_chieu = co_may_chieu;
    }

    public int getMa() {
        return ma;
    }

    public void setMa(int ma) {
        this.ma = ma;
    }

    public String getTen_phong() {
        return ten_phong;
    }

    public void setTen_phong(String ten_phong) {
        this.ten_phong = ten_phong;
    }

    public int getSuc_chua() {
        return suc_chua;
    }

    public void setSuc_chua(int suc_chua) {
        this.suc_chua = suc_chua;
    }

    public boolean isCo_may_chieu() {
        return co_may_chieu;
    }

    public void setCo_may_chieu(boolean co_may_chieu) {
        this.co_may_chieu = co_may_chieu;
    }

    @Override
    public String toString() {
        String trangthai = co_may_chieu ? "CÓ" : "KHÔNG";
        return "Phòng: " + ten_phong + "\n" +
                "Sức chứa: " + suc_chua + " người\n" +
                "Máy chiếu: " + trangthai;
    }
}