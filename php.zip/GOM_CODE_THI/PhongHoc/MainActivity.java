package com.example.phonghoc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    String URL_LOGIN = "http://192.168.1.8/v/de4_phonghoc/login_de4.php";

    EditText edtID, edtPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtID = findViewById(R.id.edtID);
        edtPass = findViewById(R.id.edtPasscode);
        findViewById(R.id.btnLogin).setOnClickListener(view -> login());
    }

    private void login() {
        String id = edtID.getText().toString().trim();
        String pass = edtPass.getText().toString().trim();

        if (id.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_LOGIN,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        String res = jsonObject.optString("ok");
                        if ("1".equals(res)) {
                            Toast.makeText(this, "Login OK!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(this, MainActivity2.class));
                            finish();
                        } else {
                            Toast.makeText(this, "Sai tài khoản hoặc mật khẩu", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        Toast.makeText(this, "Lỗi xử lý dữ liệu", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Lỗi kết nối mạng", Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user", id);
                params.put("pass", pass);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }
}