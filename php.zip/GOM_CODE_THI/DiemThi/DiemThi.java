package com.example.diemthi;

public class DiemThi {
    private int ma_diem;
    private  int ma_sinh_vien;
    private String mon_hoc;
    private double diem;
    private String xep_loai;


    public int getMa_diem() {
        return ma_diem;
    }

    public void setMa_diem(int ma_diem) {
        this.ma_diem = ma_diem;
    }

    public int getMa_sinh_vien() {
        return ma_sinh_vien;
    }

    public void setMa_sinh_vien(int ma_sinh_vien) {
        this.ma_sinh_vien = ma_sinh_vien;
    }

    public String getMon_hoc() {
        return mon_hoc;
    }

    public void setMon_hoc(String mon_hoc) {
        this.mon_hoc = mon_hoc;
    }

    public double getDiem() {
        return diem;
    }

    public void setDiem(float diem) {
        this.diem = diem;
    }

    public String getXep_loai() {
        return xep_loai;
    }

    public void setXep_loai(String xep_loai) {
        this.xep_loai = xep_loai;
    }

    public DiemThi(int ma_diem, int ma_sinh_vien, String mon_hoc, double diem, String xep_loai) {
        this.ma_diem = ma_diem;
        this.ma_sinh_vien = ma_sinh_vien;
        this.mon_hoc = mon_hoc;
        this.diem = diem;
        this.xep_loai = xep_loai;
    }

    public DiemThi(int ma_sinh_vien, String mon_hoc, double diem, String xep_loai) {
        this.ma_sinh_vien = ma_sinh_vien;
        this.mon_hoc = mon_hoc;
        this.diem = diem;
        this.xep_loai = xep_loai;
    }

    @Override
    public String toString() {
        return "MA DIEM:" + ma_diem + "\n" +
                "MA Sinh Vien:" + ma_sinh_vien + "\n" +
                "Mon Hoc:" + mon_hoc + "\n" +
                "DIEM:" + diem + "\n" +
                "XEP LOAI:" + xep_loai;
    }

    }
