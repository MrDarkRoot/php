package com.example.diemthi;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    private String URL_API = "http://192.168.1.8/v/de8_diemthi/api.php";

    EditText edtMa,edtMaSinhVien,edtMonHoc,edtDiem,edtXepLoai;

    ArrayList<DiemThi> list = new ArrayList<>();
    ArrayAdapter<DiemThi> adapter ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        edtMa = findViewById(R.id.edtMA);
        edtMaSinhVien = findViewById(R.id.edtMaSinhVien);
        edtMonHoc = findViewById(R.id.edtMonHoc);
        edtDiem = findViewById(R.id.edtDiem);
        edtXepLoai = findViewById(R.id.edtXepLoai);

        ListView listView = findViewById(R.id.listViewMain);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);

        listView.setAdapter(adapter);

        findViewById(R.id.btnAdd).setOnClickListener(view -> addData());


        loadData();

    }
    private  void callAPI(String url,Runnable onSuccess){
        StringRequest stringRequest = new StringRequest(
                Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);

                        // TRICK: Truy cập thẳng tầng sâu nhất, mặc kệ status code
                        JSONArray array = jsonObject.getJSONObject("payload").getJSONArray("items");

                        list.clear();
                        for (int i = 0; i < array.length(); i++) {
                            JSONObject obj = array.getJSONObject(i);
                            // TRICK: Dùng opt để không phải try-catch từng dòng bên trong
                            list.add(new DiemThi(
                                    obj.optInt("MA_DIEM"),
                                    obj.optInt("MA_SINH_VIEN"),
                                    obj.optString("MON_HOC"),
                                    obj.optDouble("DIEM"),
                                    obj.optString("XEP_LOAI")
                            ));
                        }
                        adapter.notifyDataSetChanged();

                    } catch (Exception e) {
                        Toast.makeText(this, "Xong!", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Toast.makeText(this, "ERROR NET FIX URL", Toast.LENGTH_SHORT).show();
                });
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void loadData(){
        callAPI(URL_API+"?action=getall", null);


    }
    private void addData() {

    }
}
