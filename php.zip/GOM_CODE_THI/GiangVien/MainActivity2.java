package com.example.giangvien;

import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.giangvien.model.GiangVien;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    String URL = "http://192.168.1.8/onthi/de2_giangvien/api.php";

    ArrayList<GiangVien> list = new ArrayList<>();
    ArrayAdapter<GiangVien> adapter;
    EditText edtTen, edtEmail, edtChuyenMon, edtDangDay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_main);

        edtTen = findViewById(R.id.edtTen);
        edtEmail = findViewById(R.id.edtEmail);
        edtChuyenMon = findViewById(R.id.edtChuyenMon);
        edtDangDay = findViewById(R.id.edtDangDay);
        ListView listView = findViewById(R.id.ListViewMain);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);

        findViewById(R.id.btnThem).setOnClickListener(view -> addData());

        // SỰ KIỆN XÓA: Nhấn giữ item để xóa
        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            deleteData(list.get(position).getMa());
            return true;
        });

        loadData();
    }

    // ... các phần import giữ nguyên ...

    void callApi(String url, Runnable onSuccess) {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);

                        // TRƯỜNG HỢP 1: NẾU CÓ DỮ LIỆU DANH SÁCH (Lấy từ loadData)
                        if (jsonObject.has("DS_GIANG_VIEN")) {
                            JSONArray array = jsonObject.optJSONArray("DS_GIANG_VIEN");
                            list.clear();
                            if (array != null) {
                                for (int i = 0; i < array.length(); i++) {
                                    JSONObject object = array.getJSONObject(i);
                                    list.add(new GiangVien(
                                            object.optInt("MA_GIANG_VIEN"),
                                            object.optString("HO_TEN"),
                                            object.optString("EMAIL"),
                                            object.optString("CHUYEN_MON"),
                                            object.optString("DANG_DAY").equalsIgnoreCase("TRUE")
                                    ));
                                }
                            }
                            adapter.notifyDataSetChanged(); // Cập nhật giao diện ngay lập tức
                        }

                        // TRƯỜNG HỢP 2: NẾU LÀ PHẢN HỒI THÀNH CÔNG CỦA INSERT/DELETE/UPDATE
                        // Dựa trên file PHP: Insert trả về "created_id", Delete trả về "deleted"
                        else if (jsonObject.has("created_id") || jsonObject.has("deleted") || jsonObject.has("updated")) {
                            Toast.makeText(this, "Thao Tác Thành Công!", Toast.LENGTH_SHORT).show();

                            // QUAN TRỌNG: Nếu có hàm callback (loadData) thì thực thi để refresh
                            if (onSuccess != null) {
                                onSuccess.run();
                            }
                        }

                    } catch (Exception e) {
                        // Nếu Server trả về JSON lỗi hoặc không đúng định dạng
                        Toast.makeText(this, "Lỗi phân giải: " + response, Toast.LENGTH_LONG).show();
                    }
                },
                error -> Toast.makeText(this, "Lỗi kết nối mạng", Toast.LENGTH_SHORT).show()
        );
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void loadData() {
        callApi(URL + "?action=getall", null);
    }

    private void addData() {
        // MAPPING GỬI ĐI: Phải khớp $_REQUEST['ho_ten'] và $_REQUEST['email']
        String url = Uri.parse(URL).buildUpon()
                .appendQueryParameter("action", "insert")
                .appendQueryParameter("ho_ten", edtTen.getText().toString()) // Đổi từ hoTen thành ho_ten
                .appendQueryParameter("email", edtEmail.getText().toString())
                .appendQueryParameter("chuyen_mon", edtChuyenMon.getText().toString())
                .appendQueryParameter("dang_day", edtDangDay.getText().toString())
                .toString();
        callApi(url, this::loadData);
    }

    private void deleteData(int maGiangVien) {
        // MAPPING GỬI ĐI: Khóa chính là ma_giang_vien
        String url = Uri.parse(URL).buildUpon()
                .appendQueryParameter("action", "delete")
                .appendQueryParameter("ma_giang_vien", String.valueOf(maGiangVien))
                .toString();
        callApi(url, this::loadData);
    }
}