package com.example.monhoc;

import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.monhoc.model.MonHoc;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    String URL = "http://192.168.1.8/onthi/de1_monhoc/api.php";

    ArrayList<MonHoc> list = new ArrayList<>();
    ArrayAdapter<MonHoc> adapter;
    EditText edtTen, edtSoTinChi, edtDangMo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_monhoc);

        edtTen = findViewById(R.id.edtTen_mon_hoc);
        edtSoTinChi = findViewById(R.id.edtSo_Tin_Chi);
        edtDangMo = findViewById(R.id.edtDang_Mo);

        ListView listView = findViewById(R.id.ListViewMain);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);

        findViewById(R.id.btnThem).setOnClickListener(view -> addData());

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            deleteData(list.get(position).getTen_mon_hoc());
            return true;
        });

        //  gọi loadData khi app vừa mở !
        loadData();
    }

    void callApi(String url, Runnable onSuccess) {
        Volley.newRequestQueue(this).add(new StringRequest(Request.Method.GET, url,
                res -> {
                    try {
                        JSONObject json = new JSONObject(res);

                        // TRICK 1: Nối đuôi lấy thẳng Array "items" nằm trong "data"
                        // Cách này bỏ qua được 2 tầng if (jsonObject -> data -> items)
                        JSONArray arr = json.optJSONObject("data").optJSONArray("items");

                        if (arr != null) {
                            list.clear();
                            for (int i = 0; i < arr.length(); i++) {
                                JSONObject o = arr.getJSONObject(i);
                                // TRICK 2: Mapping chuẩn Key viết HOA (TEN_MON_HOC, SO_TIN_CHI...)
                                list.add(new MonHoc(
                                        o.optInt("MA_MON_HOC"),
                                        o.optString("TEN_MON_HOC"),
                                        o.optInt("SO_TIN_CHI"),
                                        o.optString("DANG_MO").equalsIgnoreCase("TRUE") // Ép kiểu tại chỗ
                                ));
                            }
                            adapter.notifyDataSetChanged();
                        }

                        // TRICK 3: Dùng key "status": 1 để check thành công cho mọi thao tác
                        if (json.optInt("status") == 1) {
                            if (onSuccess != null) {
                                onSuccess.run();
                                Toast.makeText(this, "Thành công!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    } catch (Exception e) { e.printStackTrace(); }
                },
                err -> Toast.makeText(this, "Lỗi mạng", Toast.LENGTH_SHORT).show()
        ));
    }

    private void loadData() {
        callApi(URL + "?action=getall", null);
    }

    private void addData() {
        // Lấy dữ liệu từ ô nhập
        String ten = edtTen.getText().toString().trim();
        String stc = edtSoTinChi.getText().toString().trim();
        String dang = edtDangMo.getText().toString().trim();

        // MAPPING GỬI ĐI: Phải khớp với $_REQUEST['...'] trong PHP (Thường là chữ thường)
        String url = Uri.parse(URL).buildUpon()
                .appendQueryParameter("action", "insert")       // "action" viết thường
                .appendQueryParameter("ten_mon_hoc", ten)       // "ten_mon_hoc" viết thường
                .appendQueryParameter("so_tin_chi", stc)         // "so_tin_chi" viết thường
                .appendQueryParameter("dang_mo", dang)           // "dang_mo" viết thường
                .toString();

        callApi(url, this::loadData);
    }

    private void deleteData(String tenMonHoc){
        String ten = edtTen.getText().toString().trim();

        String url = Uri.parse(URL).buildUpon()
                .appendQueryParameter("action", "delete")       // "action" viết thường
                .appendQueryParameter("ten_mon_hoc", String.valueOf(ten))       // "ten_mon_hoc" viết thường
                .toString();

        callApi(url, this::loadData);

    }
}
