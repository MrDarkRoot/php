package com.example.monhoc.model;

public class MonHoc {
    private  int ma_mon_hoc;
    private String ten_mon_hoc;
    private int so_tin_chi;
    private boolean dang_mo;

    public int getMa_mon_hoc() {
        return ma_mon_hoc;
    }

    public void setMa_mon_hoc(int ma_mon_hoc) {
        this.ma_mon_hoc = ma_mon_hoc;
    }

    public String getTen_mon_hoc() {
        return ten_mon_hoc;
    }

    public void setTen_mon_hoc(String ten_mon_hoc) {
        this.ten_mon_hoc = ten_mon_hoc;
    }

    public boolean isDang_mo() {
        return dang_mo;
    }

    public void setDang_mo(boolean dang_mo) {
        this.dang_mo = dang_mo;
    }

    public int getSo_tin_chi() {
        return so_tin_chi;
    }

    public MonHoc(int ma_mon_hoc, String ten_mon_hoc, int so_tin_chi, boolean dang_mo) {
        this.ma_mon_hoc = ma_mon_hoc;
        this.ten_mon_hoc = ten_mon_hoc;
        this.so_tin_chi = so_tin_chi;
        this.dang_mo = dang_mo;
    }

    public void setSo_tin_chi(int so_tin_chi) {
        this.so_tin_chi = so_tin_chi;
    }

    public MonHoc(String ten_mon_hoc, int so_tin_chi, boolean dang_mo) {
        this.ten_mon_hoc = ten_mon_hoc;
        this.so_tin_chi = so_tin_chi;
        this.dang_mo = dang_mo;
    }

    public MonHoc() {
    }

    @Override
    public String toString() {
        return "TEN_MON_HOC:" + ten_mon_hoc + "\n" +
                "SO_TIN_CHI:" + so_tin_chi + "\n" +
                "DANG_MO:" + dang_mo ;
    }
}
