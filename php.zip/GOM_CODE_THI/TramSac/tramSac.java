package com.example.tramsac.model;

public class tramSac {
    private String tenTram;
    private int  soCongTac;
    private String hoatDong;

    public tramSac(String tenTram, String hoatDong, int soCongTac) {
        this.tenTram = tenTram;
        this.hoatDong = hoatDong;
        this.soCongTac = soCongTac;
    }

    public tramSac() {
    }

    public String getTenTram() {
        return tenTram;
    }

    public void setTenTram(String tenTram) {
        this.tenTram = tenTram;
    }

    public int getSoCongTac() {
        return soCongTac;
    }

    public void setSoCongTac(int soCongTac) {
        this.soCongTac = soCongTac;
    }

    public String getHoatDong() {
        return hoatDong;
    }

    public void setHoatDong(String hoatDong) {
        this.hoatDong = hoatDong;
    }

    @Override
    public String toString() {
        String trangThai = "TRUE".equalsIgnoreCase(hoatDong)?"HOAT DONG":"NGUNG HOAT DONG";
        return "TEN TRAM:" + tenTram +"\n" +
                "So Cong:" +   soCongTac + "\n" +
                "Trang Thai:" + trangThai;

    }
}
