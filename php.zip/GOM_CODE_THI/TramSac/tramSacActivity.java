package com.example.tramsac;

import android.app.AlertDialog;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.tramsac.model.tramSac;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class tramSacActivity extends AppCompatActivity {

    String URL_API = "http://192.168.1.8/wsTramsac/api.php";

    ArrayList<tramSac> list = new ArrayList<>();
    ArrayAdapter<tramSac> adapter;

    EditText edtTen,edtSo,edtHoatDong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.item_tramsac);

        edtTen = findViewById(R.id.edtTen);
        edtSo = findViewById(R.id.edtSoCong);
        edtHoatDong = findViewById(R.id.edtHoatDong);

        ListView listView = findViewById(R.id.listViewTramSac);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);

        listView.setAdapter(adapter);


        findViewById(R.id.btnThem).setOnClickListener(view -> addData());



       listView.setOnItemLongClickListener((adapterView, view, i, l) -> {
           deleteData(list.get(i).getTenTram());
           return true;
       });

        loadData();

    }

    void callApi(String url, Runnable onSuccess) {
        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);

                        // CÁCH KIỂM TRA MỚI: Nếu có mảng DS_TRAM_SAC thì là Load Data
                        if (jsonObject.has("DS_TRAM_SAC")) {
                            JSONArray array = jsonObject.optJSONArray("DS_TRAM_SAC");
                            list.clear();
                            if (array != null) {
                                for (int i = 0; i < array.length(); i++) {
                                    JSONObject o = array.getJSONObject(i);
                                    // Khớp đúng Constructor của bạn: Tên, Hoạt động, Số cổng
                                    list.add(new tramSac(
                                            o.optString("TEN_TRAM"),
                                            o.optString("HOAT_DONG"),
                                            o.optInt("SO_CONG_SAC")
                                    ));
                                }
                                adapter.notifyDataSetChanged();
                            }
                        }
                        // Ngược lại, nếu có biến "ok" thì là Thêm/Xóa thành công
                        else if (jsonObject.optBoolean("ok")) {
                            Toast.makeText(this, "Thao tác thành công!", Toast.LENGTH_SHORT).show();
                            if (onSuccess != null) onSuccess.run(); // Gọi loadData() để làm mới giao diện
                        }

                    } catch (Exception e) {
                        Toast.makeText(this, "Lỗi phân giải JSON: " + response, Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    String message = (error.getMessage() != null) ? error.getMessage() : "Server không phản hồi";
                    Toast.makeText(this, "Lỗi Volley: " + message, Toast.LENGTH_LONG).show();
                }
        );
        Volley.newRequestQueue(this).add(request);
    }

    private void loadData() {
        callApi(URL_API, null);
    }

     void addData() {
        String url = Uri.parse(URL_API).buildUpon()
                .appendQueryParameter("action", "insert")
                .appendQueryParameter("ten_tram", edtTen.getText().toString())
                .appendQueryParameter("so_cong_sac", edtSo.getText().toString())
                .appendQueryParameter("hoat_dong", edtHoatDong.getText().toString()).toString();

        callApi(url, this::loadData);
    }

    void deleteData(String tenTram){
        new AlertDialog.Builder(this).setTitle("Xoa" +  tenTram + "?")
                .setPositiveButton("YES", (d,w)->{
                    String url = Uri.parse(URL_API).buildUpon()
                            .appendQueryParameter("action", "delete")
                            .appendQueryParameter("ten_tram", tenTram).toString();
                    callApi(url, this::loadData);
                })
                .setNegativeButton("NO", null)
                .show();

    }

}
