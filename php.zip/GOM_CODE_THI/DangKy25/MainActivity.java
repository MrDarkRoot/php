package com.example.dangky;

import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private static final String BASE_URL = "http://10.0.2.2/de5_dangky/";
    private static final String URL_API = BASE_URL + "api.php";
    private static final String URL_LOGIN = BASE_URL + "login_de5.php";

    private EditText etHoTen, etKhoaHoc, etHocKy, etTrangThai;
    private Button btnAdd, btnDelete, btnUpdate;
    private ListView lvDangKy;

    private ArrayList<DangKyKhoaHoc> dataList;
    private ArrayAdapter<DangKyKhoaHoc> adapter;
    private DangKyKhoaHoc selectedItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize Views
        etHoTen = findViewById(R.id.etHoTen);
        etKhoaHoc = findViewById(R.id.etKhoaHoc);
        etHocKy = findViewById(R.id.etHocKy);
        etTrangThai = findViewById(R.id.etTrangThai);
        btnAdd = findViewById(R.id.btnAdd);
        btnDelete = findViewById(R.id.btnDelete);
        btnUpdate = findViewById(R.id.btnUpdate);
        lvDangKy = findViewById(R.id.lvDangKy);

        // Initialize Adapter
        dataList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataList);
        lvDangKy.setAdapter(adapter);

        // Event Listeners
        lvDangKy.setOnItemClickListener((parent, view, position, id) -> {
            selectedItem = dataList.get(position);
            etHoTen.setText(selectedItem.getHo_ten());
            etKhoaHoc.setText(selectedItem.getKhoa_hoc());
            etHocKy.setText(selectedItem.getHoc_ky());
            etTrangThai.setText(selectedItem.getTrang_thai());
        });

        btnAdd.setOnClickListener(v -> addData());
        btnDelete.setOnClickListener(v -> deleteData());
        
        // Login and Load Data
        login();
    }

    private void login() {
        StringRequest request = new StringRequest(Request.Method.POST, URL_LOGIN,
                response -> {
                    Toast.makeText(MainActivity.this, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show();
                    callApi(URL_API, null);
                },
                error -> Toast.makeText(MainActivity.this, "Đăng nhập thất bại!", Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user", "dangky");
                params.put("pass", "dk@123");
                return params;
            }
        };
        Volley.newRequestQueue(this).add(request);
    }

    private void callApi(String url, Runnable onSuccess) {
        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        
                        if (jsonObject.has("data")) {
                            JSONArray array = jsonObject.optJSONArray("data");
                            dataList.clear();
                            if (array != null) {
                                for (int i = 0; i < array.length(); i++) {
                                    JSONObject item = array.getJSONObject(i);
                                    int ma = item.optInt("ma_dang_ky");
                                    String ht = item.optString("ho_ten");
                                    String kh = item.optString("khoa_hoc");
                                    String hk = item.optString("hoc_ky");
                                    String tt = item.optString("trang_thai");
                                    dataList.add(new DangKyKhoaHoc(ma, ht, kh, hk, tt));
                                }
                            }
                            adapter.notifyDataSetChanged();
                            if (onSuccess != null) {
                                onSuccess.run();
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(MainActivity.this, "Lỗi dữ liệu", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(MainActivity.this, "Lỗi kết nối", Toast.LENGTH_SHORT).show());
        Volley.newRequestQueue(this).add(request);
    }

    private void addData() {
        Uri.Builder builder = Uri.parse(URL_API).buildUpon();
        builder.appendQueryParameter("ho_ten", etHoTen.getText().toString());
        builder.appendQueryParameter("khoa_hoc", etKhoaHoc.getText().toString());
        builder.appendQueryParameter("hoc_ky", etHocKy.getText().toString());
        builder.appendQueryParameter("trang_thai", etTrangThai.getText().toString());
        String url = builder.build().toString();

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    Toast.makeText(MainActivity.this, "Thêm thành công", Toast.LENGTH_SHORT).show();
                    etHoTen.setText("");
                    etKhoaHoc.setText("");
                    etHocKy.setText("");
                    etTrangThai.setText("");
                    callApi(URL_API, null);
                },
                error -> Toast.makeText(MainActivity.this, "Lỗi thêm", Toast.LENGTH_SHORT).show());
        Volley.newRequestQueue(this).add(request);
    }

    private void deleteData() {
        if (selectedItem == null) {
            Toast.makeText(this, "Chọn mục cần xóa", Toast.LENGTH_SHORT).show();
            return;
        }

        Uri.Builder builder = Uri.parse(URL_API).buildUpon();
        builder.appendQueryParameter("ma_dang_ky", String.valueOf(selectedItem.getMa_dang_ky()));
        String url = builder.build().toString();

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    Toast.makeText(MainActivity.this, "Xóa thành công", Toast.LENGTH_SHORT).show();
                    selectedItem = null;
                    callApi(URL_API, null);
                },
                error -> Toast.makeText(MainActivity.this, "Lỗi xóa", Toast.LENGTH_SHORT).show());
        Volley.newRequestQueue(this).add(request);
    }
}