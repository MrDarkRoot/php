package com.example.sanpham;

public class SanPham {
    private  int id;
    private String name;
    private int price;
    private int stock;
    private  Boolean con_ban;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public Boolean getCon_ban() {
        return con_ban;
    }

    public void setCon_ban(Boolean con_ban) {
        this.con_ban = con_ban;
    }

    public SanPham(String name, int price, int stock, Boolean con_ban) {
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.con_ban = con_ban;
    }

    public SanPham(int id, String name, int price, int stock, Boolean con_ban) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.con_ban = con_ban;
    }

    @Override
    public String toString() {
        String TrangThai = con_ban ? "CON" : "HET HANG";
        return "id:" + id + "\n" +
                "name:" + name + "\n" +
                "price:" + price + "\n" +
                "stock:" + stock + "\n" +
                "on_sale:" + con_ban;

    }
}
