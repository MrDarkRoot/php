package com.example.sanpham;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    String URL_LOGIN = "http://192.168.1.8/v/de6_sanpham/login_de6.php";

    EditText edtUser,edtPass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        edtUser = findViewById(R.id.edtUser);
        edtPass = findViewById(R.id.edtPass);

        findViewById(R.id.btnLogin).setOnClickListener(view -> login());


    }

    private void login() {
        String user = edtUser.getText().toString().trim();
        String pass = edtPass.getText().toString().trim();

        StringRequest stringRequest = new StringRequest(Request.Method.POST,
                URL_LOGIN,
                response -> {
            try{
                JSONObject jsonObject = new JSONObject(response);
                String res = jsonObject.optString("ok");
                if("1".equals(res)){
                    Toast.makeText(this, "Login OK!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(this,MainActivity2.class));

                }
                else {
                    Toast.makeText(this, "Wrong Creds", Toast.LENGTH_SHORT).show();
                }
            }

            catch (Exception e){
                //
            }

                }

                , error -> {
            Toast.makeText(this, "Error Net ,Fix URL", Toast.LENGTH_SHORT).show();

        })
        {
          @Override
          protected Map<String,String> getParams(){
              Map<String,String> params = new HashMap<>();
              params.put("user", user);
              params.put("pass", pass);
              return  params;
          }
        };
        Volley.newRequestQueue(this).add(stringRequest);

    }
}