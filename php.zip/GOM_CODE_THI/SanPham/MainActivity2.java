package com.example.sanpham;

import android.app.AlertDialog;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    String URL_API = "http://192.168.1.8/v/de6_sanpham/api.php";

    ArrayList<SanPham> list = new ArrayList<>();
    ArrayAdapter<SanPham> adapter;

    EditText edtID,edtName,edtPrice,edtStock,edtOn_sale;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        edtID = findViewById(R.id.edtID);
        edtName = findViewById(R.id.edtName);
        edtPrice = findViewById(R.id.edtPrice);
        edtStock = findViewById(R.id.edtStock);
        edtOn_sale = findViewById(R.id.edtOnSale);

        ListView listView = findViewById(R.id.ListViewMain);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);

        listView.setAdapter(adapter);

        findViewById(R.id.btnAdd).setOnClickListener(view -> addData() );


        listView.setOnItemLongClickListener((adapterView, view, i, l) -> {
            SanPham sanPham = list.get(i);
            deleteSanPham(sanPham.getId());
            return true;
        });

        loadData();


    }

    void callAPI(String url,Runnable onSuccess){
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                url,
                response -> {
            try{
                JSONObject jsonObject = new JSONObject(response);
                    if(jsonObject.has("items")){
                        JSONArray array = jsonObject.getJSONArray("items");
                        list.clear();
                        for (int i=0;i<array.length();i++){
                            JSONObject object = array.getJSONObject(i);
                            list.add(new SanPham(
                                    object.optInt("id"),
                                    object.optString("name"),
                                    object.optInt("price"),
                                    object.optInt("stock"),
                                    object.optBoolean("on_sale"))
                            );
                        }
                        adapter.notifyDataSetChanged();

                    if (onSuccess != null) {
                        Toast.makeText(this, "Thành công!", Toast.LENGTH_SHORT).show();
                        onSuccess.run();
                    }
                }

            }
            catch (Exception e){
                e.printStackTrace();
            }
                },
                error -> {
                    Toast.makeText(this, "Loi Mang", Toast.LENGTH_SHORT).show();

                });
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void loadData() {
        callAPI(URL_API+"?action=getall", null);

    }

    private void addData() {
        String name = edtName.getText().toString().trim();
        String price = edtPrice.getText().toString().trim();

        String stock = edtStock.getText().toString().trim();
        String on_sale = edtOn_sale.getText().toString().trim();

        String url = Uri.parse(URL_API).buildUpon()
                .appendQueryParameter("action", "insert")
                .appendQueryParameter("ten_san_pham", name)
                .appendQueryParameter("gia", price)
                .appendQueryParameter("ton_kho", stock)
                .appendQueryParameter("con_ban", on_sale)
                .toString();
        callAPI(url, this::loadData);



    }

    private  void deleteSanPham(int id){
        new AlertDialog.Builder(this).setTitle("Xac nhan")
                .setPositiveButton("YES", (d,w) -> {
                    String url = Uri.parse(URL_API).buildUpon()
                                    .appendQueryParameter("action", "delete")
                                            .appendQueryParameter("ma_san_pham", String.valueOf(id))
                                                    .toString();


                    callAPI(url, this::loadData);
                })
                .setNegativeButton("NO", null)
                .show();
    }

}
