package com.example.phongban;

public class PhongBan {

    private int ma;
    private  String ten;
    private String ten_truongPhong;
    private int nhansu;
    private Boolean dang_hoat_dong;

    public int getMa() {
        return ma;
    }

    public void setMa(int ma) {
        this.ma = ma;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getTen_truongPhong() {
        return ten_truongPhong;
    }

    public void setTen_truongPhong(String ten_truongPhong) {
        this.ten_truongPhong = ten_truongPhong;
    }

    public int getNhansu() {
        return nhansu;
    }

    public void setNhansu(int nhansu) {
        this.nhansu = nhansu;
    }

    public Boolean getDang_hoat_dong() {
        return dang_hoat_dong;
    }

    public void setDang_hoat_dong(Boolean dang_hoat_dong) {
        this.dang_hoat_dong = dang_hoat_dong;
    }

    public PhongBan(String ten, String ten_truongPhong, int nhansu, Boolean dang_hoat_dong) {
        this.ten = ten;
        this.ten_truongPhong = ten_truongPhong;
        this.nhansu = nhansu;
        this.dang_hoat_dong = dang_hoat_dong;
    }

    public PhongBan(int ma, String ten, String ten_truongPhong, int nhansu, Boolean dang_hoat_dong) {
        this.ma = ma;
        this.ten = ten;
        this.ten_truongPhong = ten_truongPhong;
        this.nhansu = nhansu;
        this.dang_hoat_dong = dang_hoat_dong;
    }

    @Override
    public String toString() {
        String trangthai = dang_hoat_dong?"HOAT DONG" :"NGUNG HOAT DONG";
        return "Ma:" + ma +"\n" +
                "Ho ten" + ten +"\n" +
                "ten Phong Ban:" + ten_truongPhong +"\n" +
                "So nhan su:" + nhansu +"\n" +
                "Dang hoat Dong" + trangthai ;
    }
}
