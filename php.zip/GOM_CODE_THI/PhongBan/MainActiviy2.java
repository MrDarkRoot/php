package com.example.phongban;

import android.app.AlertDialog;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActiviy2 extends AppCompatActivity {
    String URL_API = "http://192.168.1.8/v/de7_phongban/api.php" ;

    ArrayList<PhongBan> list = new ArrayList<>();
    ArrayAdapter<PhongBan> adapter;

    EditText edtMa,edtTen,edtTenTruongPhong,edtNhanSu,edtHoatDong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        edtMa = findViewById(R.id.edtID);
        edtTen = findViewById(R.id.edtTen);

        edtTenTruongPhong = findViewById(R.id.edtTruongPhong);
        edtNhanSu = findViewById(R.id.edtSoNhanSu);
        edtHoatDong = findViewById(R.id.edtHoatDong);

        ListView listView = findViewById(R.id.listViewMain);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);

        findViewById(R.id.btnAdd).setOnClickListener(view -> addData());

        //

        listView.setOnItemLongClickListener((adapterView, view, i, l) -> {
            PhongBan phongBan = list.get(i);
            deletePhongBan(phongBan.getMa());
            return  true;
        });

        loadData();

    }

    private  void callApi(String url,Runnable onSuccess){
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                url,
                response -> {
            try{
                JSONObject jsonObject = new JSONObject(response);
                if(jsonObject.has("DS_PHONG_BAN")){
                    JSONArray array = jsonObject.getJSONArray("DS_PHONG_BAN");
                    list.clear();
                    for (int i =0;i<array.length();i++){
                        JSONObject object = array.getJSONObject(i);
                        list.add(new PhongBan(
                                object.optInt("MA_PHONG_BAN"),
                                object.optString("TEN_PHONG_BAN")
                                , object.optString("TRUONG_PHONG"),
                                object.optInt("SO_NHAN_SU"),
                                object.optBoolean("DANG_HOAT_DONG")
                        ));
                    }
                    adapter.notifyDataSetChanged();

                }
                if (onSuccess != null){
                    Toast.makeText(this, "Thao Tac Thanh cong", Toast.LENGTH_SHORT).show();
                    onSuccess.run();
                }
            }
            catch (Exception e){
                //
            }
                }
                , error -> {
            Toast.makeText(this, "Loi Mang,Fix URL", Toast.LENGTH_SHORT).show();
        });
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void loadData(){
        callApi(URL_API + "?action=getall", null);

    }

    private void deletePhongBan(int id){
        new AlertDialog.Builder(this).setTitle("XAC NHAN")
                .setPositiveButton("YES", (d,w) ->{
                    String url = Uri.parse(URL_API).buildUpon()
                            .appendQueryParameter("action", "delete")
                                    .appendQueryParameter("ma_phong_ban", String.valueOf(id)).toString();


                    callApi(url, this::loadData);
                })
                .setNegativeButton("NO", null).show();
    }

    private void addData() {
        String ten_phong = edtTen.getText().toString().trim();
        String ten_truong_phong = edtTenTruongPhong.getText().toString().trim();
        String so = edtNhanSu.getText().toString().trim();
        String hoatdong = edtHoatDong.getText().toString().trim();

        String url = Uri.parse(URL_API).buildUpon()
                .appendQueryParameter("action", "insert")
                .appendQueryParameter("ten_phong_ban",ten_phong)
                .appendQueryParameter("truong_phong", ten_truong_phong)
                .appendQueryParameter("so_nhan_su", so)
                .appendQueryParameter("dang_hoat_dong", hoatdong)
                .toString();
        callApi(url, this::loadData);

    }



}
