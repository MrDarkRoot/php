package com.example.sinhvien;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    // Lưu ý: Kiểm tra kỹ folder /v/ hay /onthi/ trong URL của bạn
    String URL_API = "http://192.168.1.8/onthi/de3_sinhvien/api.php";
    ArrayList<SinhVien> list = new ArrayList<>();
    ArrayAdapter<SinhVien> adapter;
    EditText edtTen, edtLop, edtNgaySinh, edtHoatDong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_main);

        edtTen = findViewById(R.id.edtTen); edtLop = findViewById(R.id.edtLop);
        edtNgaySinh = findViewById(R.id.edtNgaySinh); edtHoatDong = findViewById(R.id.edtHoatDong);
        ListView lv = findViewById(R.id.listViewTramSac);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        lv.setAdapter(adapter);

        findViewById(R.id.btnThem).setOnClickListener(v -> addData());

        lv.setOnItemLongClickListener((p, v, pos, id) -> {
            int maSV = list.get(pos).getMa_sinh_vien();
            new AlertDialog.Builder(this).setTitle("Xóa sinh viên này?")
                    .setPositiveButton("YES", (d, w) -> deleteData(maSV))
                    .setNegativeButton("NO", null).show();
            return true;
        });

        loadData();
    }

    void callApi(String url, Runnable onSuccess) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Volley.newRequestQueue(this).add(new StringRequest(Request.Method.GET, url, res -> {
            try {
                JSONObject json = new JSONObject(res);
                JSONArray arr = json.optJSONArray("result");
                if (arr != null) {
                    list.clear();
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.getJSONObject(i);
                        list.add(new SinhVien(
                                o.optInt("id"), o.optString("name"), o.optString("class"),
                                sdf.parse(o.optString("dob")), o.optBoolean("active")
                        ));
                    }
                    adapter.notifyDataSetChanged();
                }
                if (onSuccess != null) {
                    onSuccess.run();
                    Toast.makeText(this, "Thành công!", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) { e.printStackTrace(); }
        }, err -> {
            // Hiển thị lỗi chi tiết từ Server để Debug
            String msg = "Lỗi kết nối";
            if(err.networkResponse != null) msg += ": " + err.networkResponse.statusCode;
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        }));
    }

    void loadData() { callApi(URL_API + "?action=getall", null); }

    void addData() {
        // TRICK: Phải dùng ho_ten và lop thì PHP mới chịu (xem file api.php dòng 21)
        String url = URL_API + "?action=insert"
                + "&ho_ten=" + edtTen.getText().toString()
                + "&lop=" + edtLop.getText().toString()
                + "&ngay_sinh=" + edtNgaySinh.getText().toString()
                + "&active=" + edtHoatDong.getText().toString();
        callApi(url, this::loadData);
    }

    void deleteData(int id) {
        // TRICK: Phải dùng ma_sinh_vien (xem file api.php dòng 35)
        String url = URL_API + "?action=delete&ma_sinh_vien=" + id;
        callApi(url, this::loadData);
    }
}