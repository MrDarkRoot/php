package com.example.sinhvien;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SinhVien {
    private int ma_sinh_vien;
    private String ho_ten;
    private String lop;
    private Date ngay_sinh;
    private Boolean active;


    public int getMa_sinh_vien() {
        return ma_sinh_vien;
    }

    public void setMa_sinh_vien(int ma_sinh_vien) {
        this.ma_sinh_vien = ma_sinh_vien;
    }

    public String getHo_ten() {
        return ho_ten;
    }

    public void setHo_ten(String ho_ten) {
        this.ho_ten = ho_ten;
    }

    public String getLop() {
        return lop;
    }

    public void setLop(String lop) {
        this.lop = lop;
    }

    public Date getNgay_sinh() {
        return ngay_sinh;
    }

    public void setNgay_sinh(Date ngay_sinh) {
        this.ngay_sinh = ngay_sinh;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public SinhVien(int ma_sinh_vien, String ho_ten, String lop, Date ngay_sinh, Boolean active) {
        this.ma_sinh_vien = ma_sinh_vien;
        this.ho_ten = ho_ten;
        this.lop = lop;
        this.ngay_sinh = ngay_sinh;
        this.active = active;
    }

    public SinhVien() {
    }

    @Override
    public String toString() {
        // Hiển thị đầy đủ thông tin để dễ kiểm tra
        String strNgay = (ngay_sinh != null) ? new SimpleDateFormat("yyyy-MM-dd").format(ngay_sinh) : "null";
        String strActive = (active != null && active) ? "True" : "False";
        
        return "MSV: " + ma_sinh_vien + " - " + ho_ten + "\n" +
               "Lớp: " + lop + " - NS: " + strNgay + " - Active: " + strActive;
    }
}
