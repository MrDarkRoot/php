package com.example.dangky;

public class DangKy {
    private int ma_dang_ky;
    private String ho_ten;
    private String khoa_hoc;
    private String hoc_ky;
    private  String trang_thai;

    public DangKy(int ma_dang_ky, String ho_ten, String khoa_hoc, String hoc_ky, String trang_thai) {
        this.ma_dang_ky = ma_dang_ky;
        this.ho_ten = ho_ten;
        this.khoa_hoc = khoa_hoc;
        this.hoc_ky = hoc_ky;
        this.trang_thai = trang_thai;
    }

    public String getHo_ten() {
        return ho_ten;
    }

    public void setHo_ten(String ho_ten) {
        this.ho_ten = ho_ten;
    }

    public String getKhoa_hoc() {
        return khoa_hoc;
    }

    public void setKhoa_hoc(String khoa_hoc) {
        this.khoa_hoc = khoa_hoc;
    }

    public int getMa_dang_ky() {
        return ma_dang_ky;
    }

    public void setMa_dang_ky(int ma_dang_ky) {
        this.ma_dang_ky = ma_dang_ky;
    }

    public String getHoc_ky() {
        return hoc_ky;
    }

    public void setHoc_ky(String hoc_ky) {
        this.hoc_ky = hoc_ky;
    }

    public String getTrang_thai() {
        return trang_thai;
    }

    public void setTrang_thai(String trang_thai) {
        this.trang_thai = trang_thai;
    }

    @Override
    public String toString() {

        return
                "ma_dang_ky=" + ma_dang_ky + "\n" +
                ", ho_ten='" + ho_ten + "\n" +
                ", khoa_hoc='" + khoa_hoc + "\n" +
                ", hoc_ky='" + hoc_ky + "\n" +
                ", trang_thai='" + trang_thai + "\n";
    }
}
