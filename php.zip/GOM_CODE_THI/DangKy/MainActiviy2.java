package com.example.dangky;

import android.app.AlertDialog;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActiviy2 extends AppCompatActivity {
    String URL_API = "http://192.168.1.8/v/de5_dangky/api.php";

    ArrayList<DangKy> list = new ArrayList<>();
    ArrayAdapter<DangKy> adapter;


    EditText edtMa,edtTen, edtKhoaHoc, edtHocKy,edtTrangThai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtMa = findViewById(R.id.edtMa);
        edtTen = findViewById(R.id.edtTen);

        edtKhoaHoc = findViewById(R.id.edtKhoaHoc);

        edtHocKy = findViewById(R.id.editHocKy);

        edtTrangThai = findViewById(R.id.editTrangThai);

        ListView listView = findViewById(R.id.listView);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);

        listView.setAdapter(adapter);

        findViewById(R.id.btnAdd).setOnClickListener(view -> addData());

        listView.setOnItemLongClickListener((adapterView, view, i, l) -> {
            DangKy dangKy = list.get(i);
            deleteData(dangKy.getMa_dang_ky(),dangKy.getHo_ten());
            return  true;
        } );


        loadData();
    }

    private void CallAPI(String url, Runnable onSuccess) {
        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        // Trick nối đuôi lấy items
                        JSONArray array = jsonObject.optJSONObject("data").optJSONArray("items");

                        if (array != null) {
                            list.clear();
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject obj = array.optJSONObject(i);
                                list.add(new DangKy(
                                        obj.optInt("MA_DANG_KY"),
                                        obj.optString("HO_TEN"),
                                        obj.optString("KHOA_HOC"),
                                        obj.optString("HOC_KY"),
                                        obj.optString("TRANG_THAI")
                                ));
                            }
                            adapter.notifyDataSetChanged();
                        }

                        // CỰC QUAN TRỌNG: Nếu có onSuccess thì chạy nó
                        if (onSuccess != null) {
                            onSuccess.run();
                        }
                    } catch (Exception e) { e.printStackTrace(); }
                },
                error -> Toast.makeText(this, "Lỗi mạng", Toast.LENGTH_SHORT).show());
        Volley.newRequestQueue(this).add(request);
    }

    private void loadData() {
        CallAPI(URL_API + "?action=getall", null);
    }


    private void addData() {
        String ten = edtTen.getText().toString().trim();
        String khoa = edtKhoaHoc.getText().toString().trim();
        String hoc_ky = edtHocKy.getText().toString().trim();
        String trang_thai = edtTrangThai.getText().toString();

        String url = Uri.parse(URL_API).buildUpon()
                .appendQueryParameter("action", "insert")
                .appendQueryParameter("ho_ten", ten)
                .appendQueryParameter("khoa_hoc", khoa)
                //.appendQueryParameter("hoc_ky", hoc_ky)
                //.appendQueryParameter("trang_thai", trang_thai)
                .toString();
        CallAPI(url, this::loadData);

    }

    private void deleteData(int maDangKy, String ten) {
        new AlertDialog.Builder(this)
                .setTitle("Xác nhận xóa")
                .setMessage("Bạn có muốn xóa đăng ký của: " + ten + "?")
                .setPositiveButton("YES", (d, w) -> {
                    // Sử dụng toString() chuẩn
                    String url = Uri.parse(URL_API).buildUpon()
                            .appendQueryParameter("action", "delete")
                            .appendQueryParameter("ma_dang_ky", String.valueOf(maDangKy)) // Khớp PK đề 5
                            .toString();

                    // Gọi API và truyền loadData để cập nhật ListView
                    CallAPI(url, this::loadData);
                })
                .setNegativeButton("NO", null)
                .show();
    }


}
